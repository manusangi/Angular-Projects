import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpModule} from '@angular/http';
import { GuestService } from './guest.services';
import { GuestComponent } from './app.component';

@NgModule({
  declarations: [
    GuestComponent
  ],
  imports: [
    BrowserModule, HttpModule
  ],
  providers: [GuestService],
  bootstrap: [GuestComponent]
}
)
export class AppModule { }
