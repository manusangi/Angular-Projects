import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule }      from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { Input,ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'inner-app',
  template:`<div>
       <h1>Change Detection - Inner Component</h1>
       <p>{{ employeeObj.name }}</p>
  </div>`,
  changeDetection:ChangeDetectionStrategy.Default
})

export class InnerComponent {
	
  @Input() employeeObj:any;
}

@Component({
  selector: 'app-root',
  template:`<div>
    <inner-app [employeeObj]="employee"></inner-app>
    <hr/>
    <button (click)="changeProperty()">Change Property</button>
    <button (click)="changeObject()">Change Object</button>
  </div>`
})

export class MainComponent {
	employee:{id:number,name:string};

    constructor(){
        this.employee = {id:101,name:'Karthik'};
    }

    changeProperty():void{
        this.employee.name = "Ganesh";
    }

     changeObject():void{
        this.employee = {id:102,name:"Anil"};
    }
}

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ MainComponent,InnerComponent ],
  bootstrap:    [ MainComponent ]
})
export class AppModule { }






