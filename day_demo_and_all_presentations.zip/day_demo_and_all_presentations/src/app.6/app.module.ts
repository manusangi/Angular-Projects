import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, Inject, Injectable } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {FormsModule} from '@angular/forms';

@Injectable()
export class NameService {
  private name:string="Anil";
  setName(name:string):void {
    this.name= name;
  }
  getName():string {
    return this.name;
  }
}


@Component({
  selector:'second_comp',
  template: `<div>
             <h2> Name Component </h2>
             <button (click)='getName()'> Get Name </button>
             <h3> Here is contact information for {{personName}} </h3>
             </div>
      `
})
export class SecondComponent {
      
    personName: string;
  
    constructor(@Inject( NameService) private nameserv:NameService) {
      this.personName=this.nameserv.getName();
    }
    getName():void{
      this.personName=this.nameserv.getName();
    }
  
}

@Component({
   selector:'first_comp',
   template: `<div>
              <h2> First Component </h2>
              <input type='text' value='Anil' [(ngModel)]='name'> 
              <button (click)='dowork()' > Click Me </button>
             </div>
       `
})
export class FirstComponent {
   name:string = "Anil";
   constructor(@Inject( NameService) private nameserv:NameService) {
   }
   dowork() {
    this.nameserv.setName(this.name);
   }
}

@Component({
   selector:'app-root',
   template: `<div>
                  <first_comp></first_comp>
                  <second_comp></second_comp>
              </div>
        `
})
export class AppComponent {

}



@NgModule({
  declarations: [
    AppComponent,FirstComponent,SecondComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [NameService ],
  bootstrap: [AppComponent]
}
)
export class AppModule { }
