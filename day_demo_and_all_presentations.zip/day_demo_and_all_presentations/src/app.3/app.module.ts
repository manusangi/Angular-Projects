import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import {FormsModule} from '@angular/forms';

interface Person {
  name:string,
  age:number
}

@Component({
   selector:'app-root',
   template: `
   <div>
   <h1>Template driven Form with Validation</h1>
   <hr/>
   <form novalidate (ngSubmit)="onSubmit(person.value,person.valid)" #person="ngForm">
     <div class="form-group">
     <label for="name" class="col-sm-2 control-label">Name</label>
     <div class="col-sm-10">
       <input type="text" class="form-control" id="name" #name="ngModel" required pattern="[a-zA-Z]+" placeholder="Name" name="name"  [(ngModel)]="person.name">
       <small [hidden]="name.valid || (name.pristine && !person.submitted)" class="text-danger">Name is required and only alphabets allowed</small>
     </div>
     </div>
     <div class="form-group">
     <label for="age" class="col-sm-2 control-label">Age</label>
     <div class="col-sm-10">
       <input type="text" class="form-control" id="age" required placeholder="Age" #age="ngModel" name="age"  [(ngModel)]="person.age">
         <small [hidden]="age.valid || (age.pristine && !person.submitted)" class="text-danger">Age is required</small>
     </div>
     </div>
     <div class="form-group">
     <div class="col-sm-offset-2 col-sm-10">
       <button type="submit" class="btn btn-default" [disabled]=!person.valid>Submit</button>
     </div>
     </div>
   </form>
 <div>
   
     `
})
export class AppComponent {

  onSubmit(person:Person,isValid:boolean){
    if(isValid) {
      alert("Name :" + person.name + "Age :" +person.age);
    }
  }

}

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
}
)
export class AppModule { }
