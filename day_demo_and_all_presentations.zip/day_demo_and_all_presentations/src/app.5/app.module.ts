import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, Inject } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';
import { ActivatedRoute } from '@angular/router';


@Component({
  template: `<div>
             <h2> About Component </h2>
            </div>
      `
})
class AboutComponent {
  
}

@Component({
  template: `<div>
             <h2> Contact Component </h2>
             <h3> Here is contact information for {{personName}} </h3>
             </div>
      `
})
class ContactComponent {
      
    personName: string;
  
    constructor(private route: ActivatedRoute) {
       route.params.subscribe(params => { this.personName = params['name']; });
    }
  
}

@Component({
   template: `<div>
              <h2> Home Component </h2>
             </div>
       `
})
export class HomeComponent {
   
}

@Component({
   selector:'app-root',
   template: `<div>
          <div>                            
              <a [routerLink]="['about']">About</a> 
              <a [routerLink]="['contact',personName]">Contact</a>
          </div>

             <h1> Header </h1>
             <router-outlet></router-outlet>             
             <h1> Footer </h1>
             </div>
        `
})
export class AppComponent {
    personName:string='Anil';
}

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contact/:name', component: ContactComponent },
  { path: 'contactus', redirectTo: 'contact' },
  ];


@NgModule({
  declarations: [
    AppComponent,HomeComponent,AboutComponent,ContactComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
}
)
export class AppModule { }
