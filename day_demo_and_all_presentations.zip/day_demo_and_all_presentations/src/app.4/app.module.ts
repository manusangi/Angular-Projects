import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component, Inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

//custom validator
function ageValidator(control:FormControl) : { [s:string]:boolean} {
  if(control.value > 100 ) {
    return {invalidAge:true};
  }
}

interface Person {
  personName:string,
  personAge:number
}

@Component({
   selector:'app-root',
   template: `
   <div>
   <h1>Model driven Form using Form Builder</h1>
   <hr/>
   <form class="form-horizontal" novalidate [formGroup]="personForm" (ngSubmit)="onSubmitForm()">
     <div class="form-group">
     <label for="name" class="col-sm-2 control-label">Name</label>
     <div class="col-sm-10">
       <input type="text" class="form-control" placeholder="Name" formControlName="personName">
     </div>
     </div>
     <div class="form-group">
     <label for="age" class="col-sm-2 control-label">Age</label>
     <div class="col-sm-10">
       <input type="text" class="form-control" placeholder="Age" formControlName="personAge">
     </div>
     </div>
     <div class="form-group">
     <div class="col-sm-offset-2 col-sm-10">
       <button type="submit" class="btn btn-default">Submit</button>
     </div>
     </div>
   </form>
 <div>
     `
})
export class AppComponent {
  personForm: FormGroup;
  person: Person;
  constructor(@Inject(FormBuilder) private builder:FormBuilder){
      this.buildform();
  }
  private buildform() {

        this.personForm= this.builder.group( { 
        personName: new FormControl('Anil',Validators.compose([
                Validators.required, Validators.minLength(4),Validators.maxLength(8)
        ]
         )), personAge: new FormControl(21, ageValidator)
      }

      );

    
  }

  onSubmitForm(){
      if(this.personForm.valid) {
       this.person = this.personForm.value;
       alert(this.person.personName);
      }
      else {
        alert("Form not valid");
      }
  }
   
}

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
}
)
export class AppModule { }
