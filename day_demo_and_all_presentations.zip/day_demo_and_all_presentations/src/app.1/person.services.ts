import {Injectable} from '@angular/core';


export interface IPerson {
    id: Number,
    name:String
}

@Injectable()
export class PersonService {
    getPersons() : IPerson[] {
         return [
            {id: 1001, name: 'Anil' }, 
            {id: 1002, name: 'Sunil' },
            {id: 1003, name: 'Ajay' }
         ]
    } 
}

