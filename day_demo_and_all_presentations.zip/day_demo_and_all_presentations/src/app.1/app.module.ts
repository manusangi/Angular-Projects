import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { PersonService } from './person.services';
import { Calculator } from './app.calculator.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [{
           provide: 'AddNumbers',
           useFactory : () => {
             return function(a:number, b:number) {
               return a+b;
             }
           }
  } ,
  {
         provide: 'Company_name',
         useValue: 'Capgemini'
  },
  {
        provide: 'calci',
        useClass: Calculator
  },
  PersonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
