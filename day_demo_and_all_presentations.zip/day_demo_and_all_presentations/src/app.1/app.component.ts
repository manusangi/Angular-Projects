import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { PersonService, IPerson } from './person.services'
import { Calculator } from './app.calculator.service';
@Component({
  selector: 'app-root',
  template:` <div> Hello from Angular JS 2 </div>
             <div>
                <ul *ngFor='let person of mypersons'>
                    <li> {{person.name}} </li>
                </ul>
                
                <div *ngIf='mypersons'>
                    <b> There are {{mypersons.length}} persons </b>
                </div>

             </div>
   
             `,
  
})
export class AppComponent implements OnInit, OnDestroy{
  mypersons: IPerson[];
  constructor(@Inject(PersonService) private mypersonservice:PersonService, 
         @Inject('AddNumbers') addfun:any,@Inject ('Company_name')cmpname:any,
          @Inject('calci')cal:Calculator)
  {
        console.log(addfun(4,5));
        console.log(cmpname);
        console.log(cal.add(5,5));
  }

  title = 'app';

  ngOnInit() {
    this.mypersons=this.mypersonservice.getPersons();
    console.log("Inside Init Method");
    
  }
  ngOnDestroy() {
    console.log("Inside Destroy Method");
    
  }
}
