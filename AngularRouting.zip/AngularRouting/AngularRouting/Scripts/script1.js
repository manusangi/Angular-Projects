﻿///<reference path="angular.min.js"/>
///<reference path="angular-route.min.js"/>

var app = angular.module("Demo", ["ngRoute"])
    .config(function ($routeProvider,$locationProvider) {
        $routeProvider
            .when("/home", {
                templateUrl: "Templates/home.html",
                controller: "homeController"
            })
            .when("/courses", {
                templateUrl: "Templates/courses.html",
                controller: "coursesController"
            })
            .when("/students", {
                templateUrl: "Templates/students.html",
                controller: "studentsController"
            })
        .otherwise({
            redirectTo : "/home"
            })
        $locationProvider.html5Mode(true);
    });
app.controller("homeController", function ($scope) {
    $scope.message = "this is home page";
});
app.controller("studentsController", function ($scope, $route) {
    $scope.$on("$locationChangeStart", function (event, next, current) { //$$route.originalPath
        if (!confirm("Are you sure you want to navigate away from this page to " + next)) {
            event.preventDefault();
        }
    });

    $scope.message = "this is students page";
});
app.controller("coursesController", function ($scope) {
    $scope.message = "this is courses page";
});