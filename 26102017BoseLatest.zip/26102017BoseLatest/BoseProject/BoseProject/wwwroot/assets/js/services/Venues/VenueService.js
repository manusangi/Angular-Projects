﻿app.service("VenueService", function ($http) {
    //get All Stores  
    this.getAllVenues = function () {
        return $http.get("/BoseCommon/VenueList/");
    };
    //get All Stores  
    this.getAllStores = function () {
        return $http.get("/BoseCommon/StoreList/");
    }; 

      // Adding the store  
    this.AddNewVenue = function ($scope) {
        $scope.venueModel = {};
        $scope.venueModel.StoreID = $scope.StoreID;
        $scope.venueModel.VenueName = $scope.VenueName;
        $scope.venueModel.StreetAddress = $scope.StreetAddress;
        $scope.venueModel.ContactName = $scope.ContactName;
        $scope.venueModel.ContactNumber = $scope.ContactNumber;
        $scope.venueModel.ContactEmail = $scope.ContactEmail;
        $scope.venueModel.MobilePhone = $scope.MobilePhone;
        $scope.venueModel.SecurityPhone = $scope.SecurityPhone;      
        $scope.venueModel.ContactPhone = $scope.ContactPhone;

        return $http({
            method: "post",
            url: "/BoseCommon/AddVenue/",
            data: JSON.stringify($scope.venueModel),
            dataType: "json"
        });
    }
       
    //get stores by ID
    this.getVenue = function (venueID) {
        var response = $http({
            method: "post",
            url: "/BoseCommon/GetVenueById",
            params: {
                id: JSON.stringify(venueID)
            }
        });
        return response;
    }
    // Updating the store
    this.updateVenue = function ($scope) {
        $scope.venueModel = {};
        $scope.venueModel.ID = $scope.ID;
        $scope.venueModel.StoreID = $scope.StoreID;
        $scope.venueModel.VenueName = $scope.VenueName;
        $scope.venueModel.StreetAddress = $scope.StreetAddress;
        $scope.venueModel.ContactName = $scope.ContactName;
        $scope.venueModel.ContactPhone = $scope.ContactPhone;
        $scope.venueModel.ContactEmail = $scope.ContactEmail;
        $scope.venueModel.MobilePhone = $scope.MobilePhone;
        $scope.venueModel.SecurityPhone = $scope.SecurityPhone;
        
        var response = $http({
            method: "post",
            url: "/BoseCommon/UpdateVenue/",
            data: JSON.stringify($scope.venueModel),
            dataType: "json"
        });
        return response;
    } 
    //Deleting the store
    this.deleteVenue = function (venueId) {
        var response = $http({
            method: "post",
            url: "/BoseCommon/DeleteVenue/",
            params: {
                venueId: JSON.stringify(venueId)
            }
        });
        return response;
    } 

});