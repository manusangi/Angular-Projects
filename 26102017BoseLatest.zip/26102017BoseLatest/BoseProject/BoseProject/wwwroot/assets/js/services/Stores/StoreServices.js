﻿app.service("StoreService", function ($http) {
    //get All Stores  
    this.getAllStores = function () {
        return $http.get("/BoseCommon/StoreList/");
    };  
    //get All Countries
    this.getAllCountries = function () {
        return $http.get("/BoseCommon/GetCountry");
    };
    //get All States
    this.getAllStates= function (CountryID) {
        var response = $http({
            method: 'POST',
            url: '/BoseCommon/GetStates/',
            data: CountryID,
            dataType: 'json'
        });
        return response;
    }
    //get All Districts
    this.getAllDistricts = function (StateID) {
        var response = $http({
            method: 'POST',
            url: '/BoseCommon/GetDistricts/',
            data: StateID,
            dataType: 'json'
        });
        return response;
    }
    //get All Cities
    this.getAllCities = function (DistrictID) {
        var response = $http({
            method: 'POST',
            url: '/BoseCommon/GetCities/',
            data: DistrictID,
            dataType: 'json'
        });
        return response;
    }
    //get All Regions
    this.getAllRegions = function () {
        return $http.get("/BoseCommon/GetRegion");
    };
    //get All Languages
    this.getAllLanguages = function () {
        return $http.get("/BoseCommon/GetLanguages");
    };
    //get All Store Formats
    this.getAllStoreFormats = function () {
        return $http.get("/BoseCommon/GetStoreFormat");
    };
    //get All Store Tiers
    this.getAllStoreTiers = function () {
        return $http.get("/BoseCommon/GetStoreTier");
    };
    //get stores by ID
    this.getStore = function (storeId) {
        var response = $http({
            method: "post",
            url: "/BoseCommon/GetStoreById",
            params: {
                id: JSON.stringify(storeId)
            }
        });
        return response;
    }
    // Adding the store  
    this.AddNewStore = function ($scope) {               
        $scope.storeModel = {};
        $scope.storeModel.StoreName = $scope.StoreName;
        $scope.storeModel.StoreNumber = $scope.StoreNumber;
        $scope.storeModel.StoreGeneralEmail = $scope.StoreGeneralEmail;
        $scope.storeModel.PhoneNumber = $scope.PhoneNumber;
        $scope.storeModel.StoreManager = $scope.StoreManager;
        $scope.storeModel.StoreManagerEmail = $scope.StoreManagerEmail;
        $scope.storeModel.StoreVisualLead = $scope.StoreVisualLead;
        $scope.storeModel.StoreVisualLeadEmail = $scope.StoreVisualLeadEmail;
        $scope.storeModel.StoreFormatID = $scope.StoreFormatID;
        $scope.storeModel.RegionID = $scope.RegionID;
        $scope.storeModel.DistrictID = $scope.DistrictID;
        $scope.storeModel.Tier = $scope.Tier;
        $scope.storeModel.LanguageID = $scope.LanguageID;
        $scope.storeModel.CostCenter = $scope.CostCenter;
        $scope.storeModel.AddressLine1 = $scope.AddressLine1;
        $scope.storeModel.CityID = $scope.CityID;
        $scope.storeModel.StateID = $scope.StateID;
        $scope.storeModel.ZipCode = $scope.ZipCode;
        $scope.storeModel.CountryID = $scope.CountryID;
        $scope.storeModel.Closed = $scope.Closed;
        $scope.storeModel.ClosingDate = $scope.ClosingDate;
        $scope.storeModel.SecurityRequired = $scope.SecurityRequired;
        $scope.storeModel.GeneralDates = $scope.GeneralDates;       
        
        return $http({
            method: "post",
            url: "/BoseCommon/AddStore/",
            data: JSON.stringify($scope.storeModel),
            dataType: "json"
        });
    }
    // Updating the store
    this.updateStore = function ($scope) {
        $scope.storeModel = {};
        $scope.storeModel.ID = $scope.storeId;
        $scope.storeModel.StoreName = $scope.StoreName;
        $scope.storeModel.StoreNumber = $scope.StoreNumber;
        $scope.storeModel.StoreGeneralEmail = $scope.StoreGeneralEmail;
        $scope.storeModel.PhoneNumber = $scope.PhoneNumber;
        $scope.storeModel.StoreManager = $scope.StoreManager;
        $scope.storeModel.StoreManagerEmail = $scope.StoreManagerEmail;
        $scope.storeModel.StoreVisualLead = $scope.StoreVisualLead;
        $scope.storeModel.StoreVisualLeadEmail = $scope.StoreVisualLeadEmail;
        $scope.storeModel.StoreFormatID = $scope.StoreFormatID;
        $scope.storeModel.RegionID = $scope.RegionID;
        $scope.storeModel.DistrictID = $scope.DistrictID;
        $scope.storeModel.Tier = $scope.Tier;
        $scope.storeModel.LanguageID = $scope.LanguageID;
        $scope.storeModel.CostCenter = $scope.CostCenter;
        $scope.storeModel.AddressLine1 = $scope.AddressLine1;
        $scope.storeModel.CityID = $scope.CityID;
        $scope.storeModel.StateID = $scope.StateID;
        $scope.storeModel.ZipCode = $scope.ZipCode;
        $scope.storeModel.CountryID = $scope.CountryID;
        $scope.storeModel.Closed = $scope.Closed;
        $scope.storeModel.ClosingDate = $scope.ClosingDate;
        $scope.storeModel.SecurityRequired = $scope.SecurityRequired;
        $scope.storeModel.GeneralDates = $scope.GeneralDates;
        var response = $http({
            method: "post",
            url: "/BoseCommon/UpdateStore/",
            data: JSON.stringify($scope.storeModel),
            dataType: "json"
        });
        return response;
    }
    //Deleting the store
    this.deleteStore = function (storeId) {        
        var response = $http({
            method: "post",
            url: "/BoseCommon/DeleteStore/",
            params: {
                storeId: JSON.stringify(storeId)
            }
        });
        return response;
    }    
   
});
