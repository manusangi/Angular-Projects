﻿app.service("ExportUtilityService", function ($http) {
    //get All Export Utility List  
    this.getAllExportUtility = function () {
        return $http.get("/BoseCommon/ExportUtilityList/");
    }; 
    this.SaveRegions = function (region) {
        var response = $http({
            method: "post",
            url: "/BoseCommon/SaveRegion",
            params: {
                region: JSON.stringify(region)
            }           
            
        });       
        return response;
    }
    //get All Regions
    this.getAllRegions = function () {
        return $http.get("/BoseCommon/GetRegion");
    };
    //get All Countries
    this.getAllCountries = function () {
        return $http.get("/BoseCommon/GetCountry");
    };
    //get All States
    this.getAllStates = function () {
        return $http.get("/BoseCommon/GetStates");
    };
    //get All Regions
    this.getAllDistricts = function () {
        return $http.get("/BoseCommon/GetDistricts");
    };
    //get All States
    this.getAllCities = function () {
        return $http.get("/BoseCommon/GetCities");
    };
    //get All Store Tiers
    this.getAllStoreTiers = function () {
        return $http.get("/BoseCommon/GetStoreTier");
    };
    //get All Languages
    this.getAllLanguages = function () {
        return $http.get("/BoseCommon/GetLanguages");
    };
    //get All Store Formats
    this.getAllStoreFormats = function () {
        return $http.get("/BoseCommon/GetStoreFormat");
    };
    //get All Stores  
    this.getAllStores = function () {
        return $http.get("/BoseCommon/StoreList/");
    };  
});