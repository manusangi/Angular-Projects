﻿app.directive('datepicker', function () {
    return {
        link: function (scope, el) {
            $(el).datepicker({
                onSelect: function (dateText) {
                    console.log(dateText);
                    scope.closingDate = dateText;                    
                }
            });
        }
    };
    
});