﻿var storecontroller = app.controller('storeController', function ($scope, StoreService, $http, $timeout, $q, $log) {
    //displaying storelist div
    $scope.divStoreList = true; 
    //Binding the storelist
    GetStoresList();
    //Binding the countries list
    GetCountriesList();
    //Binding the regions list
    GetRegionsList();
    //Binding the store formats
    GetStoreFormat();
    //Binding the store tier
    GetStoreTier();
    //Biniding the Languages
    GetLanguages();
    $scope.Stores = []; 

    // Binding auto complte code for store search
    //Begin 
    var self = this;   
    self.simulateQuery = true;
    self.stores = loadAllStores($http);
    self.querySearch = querySearch;
    self.selectedItemChange = selectedItemChange;
    self.searchTextChange = searchTextChange;
    function querySearch(query) {
        var results = query ? self.stores.filter(createFilterFor(query)) : self.stores, deferred;
        if (self.simulateQuery) {
            deferred = $q.defer();
            $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
            return deferred.promise;
        } else {
            return results;
        }
    }
    function selectedItemChange(item) {
        $scope.search = undefined;
        if (item.value != "") {
                $scope.search = item.value;
            }       
       
        $log.info('Item changed to ' + JSON.stringify(item));
    }
    function searchTextChange(text) {
        $log.info('Text changed to ' + text);
    }
    function loadAllStores($http) {
        var allStores = [];
        var url = '';
        var result = [];        
        StoreService.getAllStores().then(function successCallback(response) {
            allStores = response.data;
            angular.forEach(allStores, function (store, key) {
                result.push(
                    {
                        value: store.storeName.toLowerCase(),
                        display: store.storeName
                        
                    });
                //alert(store.storeName);
            });
        }, function errorCallback(response) {
            console.log('Oops! Something went wrong while fetching the data. Status Code: ' + response.status + ' Status statusText: ' + response.statusText);
        });
        return result;
    }
    function createFilterFor(query) {
        var lowercaseQuery = angular.lowercase(query);
        return function filterFn(store) {
            return (store.value.indexOf(lowercaseQuery) === 0);
        };
    };
    //End

    //Get Store list
    function GetStoresList() {
        StoreService.getAllStores().success(function (store) {          
            $scope.Stores = store;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Countries List
    function GetCountriesList() {
        StoreService.getAllCountries().success(function (country) {
            $scope.Country = country;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Regions List
    function GetRegionsList() {
        StoreService.getAllRegions().success(function (region) {
            $scope.Region = region;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Languages List
    function GetLanguages() {
        StoreService.getAllLanguages().success(function (language) {
            $scope.Languages = language;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Store Format
    function GetStoreFormat()
    {
        StoreService.getAllStoreFormats().success(function (storeformat) {
            $scope.StoreFormat = storeformat;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Store Tier
    function GetStoreTier() {
        StoreService.getAllStoreTiers().success(function (storetier) {
            $scope.StoreTier = storetier;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get States List
    $scope.GetStates = function (state) {
        if ($scope.countr) {
            var CountryID = $scope.countr;
            var getStoreData = StoreService.getAllStates(CountryID);
            getStoreData.success(function (data) {                
                $scope.states = data;
                }); 
            $(".editStateID").prop("disabled", false);
        }
        else {
            $scope.states = null;
        }
    }  
    //Get Districts List
    $scope.GetDistricts = function () {
        if ($scope.state) {
            var StateID = $scope.state;
            var getStoreData = StoreService.getAllDistricts(StateID);
            getStoreData.success(function (data) {
                $scope.districts = data;
                });
            $(".editDistrictID").prop("disabled", false);
        }
        else {
            $scope.districts = null;
        }
    }
    //Get Cities List
    $scope.GetCities = function () {
        if ($scope.district) {
            var DistrictID = $scope.district;
            var getStoreData = StoreService.getAllCities(DistrictID);
            getStoreData.success(function (data) {
                $scope.cities = data;
                });
            $(".editCity").prop("disabled", false);
        }
        else {
            $scope.cities = null;
        }
    }      
     //Dispalying view Add store   
    $scope.AddNewStore = function () {
        $scope.Action = "Add";
        $scope.divStoreList = false;
        $scope.divStore = true; 
        $(".editStateID").prop("disabled", true);
        $(".editDistrictID").prop("disabled", true);
        $(".editCity").prop("disabled", true);
        $scope.disableEditButton = { 'visibility': 'hidden' };
    }; 
    //Adding the store
    $scope.AddStore = function (store) {        
        $scope.storeModel = {};
        $scope.storeModel.storeId = $scope.storeId;
        $scope.storeModel.StoreName = $scope.storeName;
        $scope.storeModel.StoreNumber = $scope.storeNumber;
        $scope.storeModel.StoreGeneralEmail = $scope.storeGeneralEmail;
        $scope.storeModel.PhoneNumber = $scope.phoneNumber;
        $scope.storeModel.StoreManager = $scope.storeManager;
        $scope.storeModel.StoreManagerEmail = $scope.storeManagerEmail;
        $scope.storeModel.StoreVisualLead = $scope.storeVisualLead;
        $scope.storeModel.StoreVisualLeadEmail = $scope.storeVisualLeadEmail;
        $scope.storeModel.StoreFormatID = $scope.storeFormatID;
        $scope.storeModel.RegionID = $scope.region;
        $scope.storeModel.DistrictID = $scope.district;
        $scope.storeModel.Tier = $scope.storeTier;
        $scope.storeModel.LanguageID = $scope.languageID;
        $scope.storeModel.CostCenter = $scope.costCenter;
        $scope.storeModel.AddressLine1 = $scope.addressLine1;
        $scope.storeModel.CityID = $scope.cityID;
        $scope.storeModel.StateID = $scope.state;
        $scope.storeModel.ZipCode = $scope.zipCode;
        $scope.storeModel.CountryID = $scope.countr;
        $scope.storeModel.Closed = $scope.closed;
        $scope.storeModel.ClosingDate = $scope.closingDate;
        $scope.storeModel.SecurityRequired = $scope.securityRequired;
        $scope.storeModel.GeneralDates = $scope.generalDates;        
        
        StoreService.AddNewStore($scope.storeModel).success(function (msg) {
            alert(msg);
            window.location = "/api/store";
        }, function () {
            alert('error in adding record');
            });            
    }; 
    //Editiing the store
    $scope.editStore = function (store) {

        var getStoreData = StoreService.getStore(store.id);
        getStoreData.then(function (_store) {
            $scope.storeId = store.storeId;
            $scope.storeName = store.storeName;
            $scope.storeNumber = store.storeNumber;
            $scope.storeGeneralEmail = store.storeGeneralEmail;
            $scope.phoneNumber = store.phoneNumber;
            $scope.storeManager = store.storeManager;
            $scope.storeManagerEmail = store.storeManagerEmail;
            $scope.storeVisualLead = store.storeVisualLead;
            $scope.storeVisualLeadEmail = store.storeVisualLeadEmail;
            $scope.storeFormatID = store.storeFormatID;
            $scope.countr = store.countryID;
            $scope.region = store.regionID;
            $scope.storeTier = store.tierID;
            $scope.state = $scope.GetStates();
            $scope.state = store.stateID;
            $scope.district = $scope.GetDistricts();
            $scope.district = store.districtID;
            $scope.costCenter = store.costCenter;
            $scope.addressLine1 = store.addressLine1;
            $scope.languageID = store.languageID;
            $scope.zipCode = store.zipCode;
            $scope.cityID = $scope.GetCities();
            $scope.cityID = store.cityID;
            $scope.closed = store.closed;
            $scope.closingDate = store.closingDate;
            $scope.generalDates = store.generalDates;
            $scope.securityRequired = store.securityRequired;
            DisableEditStore();
            $scope.Action = "Edit";
            $scope.divStoreList = false;
            $scope.divStore = true;
            $scope.disableSubmitButton = { 'visibility': 'hidden' };
            $scope.disablePreviewButton = { 'visibility': 'hidden' };

        }, function () {
            alert('Error in getting book records');
        });
    };
    //Updating the store
    $scope.updateStore = function () {
        var store = {
            storeId: $scope.storeId,
            storeName: $scope.storeName,
            storeNumber: $scope.storeNumber,
            storeGeneralEmail: $scope.storeGeneralEmail,
            phoneNumber: $scope.phoneNumber,
            storeManager: $scope.storeManager,
            storeManagerEmail: $scope.storeManagerEmail,
            storeVisualLead: $scope.storeVisualLead,
            storeVisualLeadEmail: $scope.storeVisualLeadEmail,
            storeFormatID: $scope.storeFormatID,
            countr: $scope.countr,
            region: $scope.region,
            storeTier: $scope.storeTier,
            state: $scope.state,
            district: $scope.district,
            costCenter: $scope.costCenter,
            addressLine1: $scope.addressLine1,
            languageID: $scope.languageID,
            zipCode: $scope.zipCode,
            cityID: $scope.cityID,
            closed: $scope.closed,
            closingDate: $scope.closingDate,
            generalDates: $scope.generalDates,
            securityRequired: $scope.securityRequired
        };
        var getStoreAction = $scope.Action;
        if (getStoreAction == "Edit") {
            $scope.Action = "Update";
            EnableEditStore();
            $("#btnEdit").html('Update');
        }
        else {
            $scope.storeModel = {};
            $scope.storeModel.storeId = $scope.storeId;
            $scope.storeModel.StoreName = $scope.storeName;
            $scope.storeModel.StoreNumber = $scope.storeNumber;
            $scope.storeModel.StoreGeneralEmail = $scope.storeGeneralEmail;
            $scope.storeModel.PhoneNumber = $scope.phoneNumber;
            $scope.storeModel.StoreManager = $scope.storeManager;
            $scope.storeModel.StoreManagerEmail = $scope.storeManagerEmail;
            $scope.storeModel.StoreVisualLead = $scope.storeVisualLead;
            $scope.storeModel.StoreVisualLeadEmail = $scope.storeVisualLeadEmail;
            $scope.storeModel.StoreFormatID = $scope.storeFormatID;
            $scope.storeModel.RegionID = $scope.region;
            $scope.storeModel.DistrictID = $scope.district;
            $scope.storeModel.Tier = $scope.storeTier;
            $scope.storeModel.LanguageID = $scope.languageID;
            $scope.storeModel.CostCenter = $scope.costCenter;
            $scope.storeModel.AddressLine1 = $scope.addressLine1;
            $scope.storeModel.CityID = $scope.cityID;
            $scope.storeModel.StateID = $scope.state;
            $scope.storeModel.ZipCode = $scope.zipCode;
            $scope.storeModel.CountryID = $scope.countr;
            $scope.storeModel.Closed = $scope.closed;
            $scope.storeModel.ClosingDate = $scope.closingDate;
            $scope.storeModel.SecurityRequired = $scope.securityRequired;
            $scope.storeModel.GeneralDates = $scope.generalDates;
            store.id = $scope.storeId;
            StoreService.updateStore($scope.storeModel).success(function (msg) {
                alert(msg);
                window.location = "/api/store"
            }, function () {
                alert('Error in updating book record');
            });

        }
    };
    //Deleting the store
    $scope.DeleteStore = function ($scope) {
        
        $scope.storeModel = {};
        $scope.storeModel.storeId = $scope.storeId;
        $scope.storeModel.StoreName = $scope.storeName;
        $scope.storeModel.StoreNumber = $scope.storeNumber;
        $scope.storeModel.StoreGeneralEmail = $scope.storeGeneralEmail;
        $scope.storeModel.PhoneNumber = $scope.phoneNumber;
        $scope.storeModel.StoreManager = $scope.storeManager;
        $scope.storeModel.StoreManagerEmail = $scope.storeManagerEmail;
        $scope.storeModel.StoreVisualLead = $scope.storeVisualLead;
        $scope.storeModel.StoreVisualLeadEmail = $scope.storeVisualLeadEmail;
        $scope.storeModel.StoreFormatID = $scope.storeFormatID;
        $scope.storeModel.RegionID = $scope.regionID;
        $scope.storeModel.DistrictID = $scope.districtID;
        $scope.storeModel.Tier = $scope.tierID;
        $scope.storeModel.LanguageID = $scope.languageID;
        $scope.storeModel.CostCenter = $scope.costCenter;
        $scope.storeModel.AddressLine1 = $scope.addressLine1;
        $scope.storeModel.CityID = $scope.cityID;
        $scope.storeModel.StateID = $scope.stateID;
        $scope.storeModel.ZipCode = $scope.zipCode;
        $scope.storeModel.CountryID = $scope.countryID;
        $scope.storeModel.Closed = $scope.closed;
        $scope.storeModel.ClosingDate = $scope.closingDate;
        $scope.storeModel.SecurityRequired = $scope.securityRequired;
        $scope.storeModel.GeneralDates = $scope.generalDates;
        var getStoreData = StoreService.deleteStore($scope.storeId);
        getStoreData.then(function (msg) {
            alert(msg.data);
            window.location = "/api/store";
        }, function () {
            alert('Error in deleting book record');
        });
    };
    //Disabling the store fields
    function DisableEditStore()
    {
        $(".editStoreName").attr("disabled", "disabled");
        $(".editStoreNumber").attr("disabled", "disabled");
        $(".editStoreGeneralEmail").attr("disabled", "disabled");
        $(".editPhoneNumber").attr("disabled", "disabled");
        $(".editStoreManager").attr("disabled", "disabled");
        $(".editStoreManagerEmail").attr("disabled", "disabled");
        $(".editStoreVisualLead").attr("disabled", "disabled");
        $(".editStoreVisualLeadEmail").attr("disabled", "disabled");
        $(".editStoreFormatID").attr("disabled", "disabled");
        $(".editCountryID").attr("disabled", "disabled");
        $(".editRegionID").attr("disabled", "disabled");
        $(".editTierID").attr("disabled", "disabled");
        $(".editStateID").prop("disabled", true);
        $(".editDistrictID").prop("disabled", true);
        $(".editCostCenter").prop("disabled", true);
        $(".editAddress").prop("disabled", true);
        $(".editLanguageID").prop("disabled", true);
        $(".editZipcode").prop("disabled", true);
        $(".editCity").prop("disabled", true);
        $(".editClosed").prop("disabled", true);
        $(".editClosingDate").prop("disabled", true);
        $(".editGeneralDates").prop("disabled", true);
        $(".editSecurityRequired").prop("disabled", true);
    }
    //Enabling the store fields
    function EnableEditStore() {
        $(".editStoreName").prop("disabled", false);
        $(".editStoreNumber").prop("disabled", false);
        $(".editStoreGeneralEmail").prop("disabled", false);
        $(".editPhoneNumber").prop("disabled", false);
        $(".editStoreManager").prop("disabled", false);
        $(".editStoreManagerEmail").prop("disabled", false);
        $(".editStoreVisualLead").prop("disabled", false);
        $(".editStoreVisualLeadEmail").prop("disabled", false);
        $(".editStoreFormatID").prop("disabled", false);
        $(".editCountryID").prop("disabled", false);
        $(".editRegionID").prop("disabled", false);
        $(".editTierID").prop("disabled", false);
        $(".editStateID").prop("disabled", false);
        $(".editDistrictID").prop("disabled", false);
        $(".editCostCenter").prop("disabled", false);
        $(".editAddress").prop("disabled", false);
        $(".editLanguageID").prop("disabled", false);
        $(".editZipcode").prop("disabled", false);
        $(".editCity").prop("disabled", false);
        $(".editClosed").prop("disabled", false);
        $(".editClosingDate").prop("disabled", false);
        $(".editGeneralDates").prop("disabled", false);
        $(".editSecurityRequired").prop("disabled", false);
    }
      
});

