﻿var ExportUtilityController = app.controller('ExportUtilityController', function ($http, $scope, ExportUtilityService) {

    $scope.divExportUtilityList = true;
    $scope.divStoreExportUtility = false;
    $scope.divVenueExportUtility = false;
    GetRegionsList();
    GetDistrictsList();
    GetCountriesList();
    GetStatesList();
    GetCitiesList();
    GetStoreTier();
    GetLanguages();
    GetStoreFormat();
    GetStoresList();
    $scope.selectedFile = null;
    $scope.msg = "";
    var region = null;
    var country = null;
    var state = null;
    var district = null;
    var city = null;
    var storetier = null;
    var language = null;
    var storeformat = null;
    var store = null;
    $scope.GenerateTable = function () {

        var listID = $scope.List;
        if (listID == 1) {
            $scope.divStoreExportUtility = true;
            $scope.divVenueExportUtility = false;
            $scope.excel = $scope.excel["StoreList.xlsx"].Sheet1;
        }
        else {

            $scope.divVenueExportUtility = true;
            $scope.divStoreExportUtility = false;
            $scope.excel = $scope.excel["VenueList.xlsx"].Sheet1;
        }
    };  
    $scope.loadFile = function (files) {

        $scope.$apply(function () {

            $scope.selectedFile = files[0];

        })

    }
    $scope.handleFile = function () {

        var file1 = $scope.selectedFile;
        var readOpts = {
            type: 'binary'
        };
        var master = {};
        var reader = new FileReader();
        reader.onload = function (
            file) {
            var wb = XLSX
                .read(
                file.target.result,
                readOpts);
            master[file1.name] = {};
            angular
                .forEach(
                wb.SheetNames,
                function (
                    name) {
                    master[file1.name][name] = XLSX.utils
                        .sheet_to_json(wb.Sheets[name]);
                    var first_sheet_name = wb.SheetNames[0];

                    var excelData = XLSX.utils.sheet_to_json(wb.Sheets[first_sheet_name]);
                    if (excelData.length > 0) {


                        $scope.save(excelData);


                    } else {
                        $scope.msg = "Error : Something Wrong !";
                    }

                });
            //if (file1 === el[0].files[len]) {
            //    modelSetter(
            //        scope,
            //        master);
            //    scope
            //        .$apply();
            //}
        }
        reader
            .readAsBinaryString(file1);

    }
    $scope.save = function (data) {
        var listID = $scope.List;
      
        if (listID == 1) {
            $scope.storelist = [];
         
            var lastDistrictID = $scope.maxDistrictID;
            var lastRegionID = $scope.maxRegionID;
            var lastCountryID = $scope.maxCountryID;
            var lastStateID = $scope.maxStateID;
            var lastCityID = $scope.maxCityID;
            var lastStoreTierID = $scope.maxStoreTierID;
            var lastLanguageID = $scope.maxLanguageID;
            var lastStoreFormatID = $scope.maxStoreFormatID;

            var regionlist = [];
            var countrieslist = [];
            var stateslist = [];
            var districtslist = [];
            var citieslist = [];
            var storetierlist = [];
            var languageslist = [];
            var storeFormatslist = [];
            angular.forEach(data, function (value, key) {
                $scope.StoreModel = {};
                $scope.StoreModel.StoreName = value.StoreName;
                $scope.StoreModel.StoreNumber = value.StoreNumber;
                $scope.StoreModel.StoreGeneralEmail = value.StoreGeneralEmail;
                $scope.StoreModel.PhoneNumber = value.PhoneNumber;
                $scope.StoreModel.StoreManager = value.StoreManager;
                $scope.StoreModel.StoreManagerEmail = value.StoreManagerEmail;
                $scope.StoreModel.StoreVisualLead = value.StoreVisualLead;
                $scope.StoreModel.StoreVisualLeadEmail = value.StoreVisualLeadEmail;
                $scope.StoreModel.AddressLine1 = value.Address;
                
                region = _.where($scope.Region, { regionDescription: value.Region });
                if (region.length == 0) {
                   
                    $scope.StoreModel.RegionID = lastRegionID + 1;

                    lastRegionID = lastRegionID + 1;
                    regionlist.push({ RegionID: lastRegionID, RegionCode: value.Region, RegionDescription: value.Region, Flag: "True" });
                }
                else {
                    $scope.StoreModel.RegionID = region[0].regionID;
                    regionlist.push({ RegionID: region[0].regionID, RegionCode: value.Region, RegionDescription: value.Region, Flag: "True" });
                }

                country = _.where($scope.Country, { countryName: value.Country });
                if (country.length == 0) {
               
                    $scope.StoreModel.CountryID = lastCountryID + 1;
                    lastCountryID = lastCountryID + 1;
                    countrieslist.push({ CountryID: lastCountryID, CountryName: value.Country, Flag: "True" });
                    
                }
                else
                {
                    $scope.StoreModel.CountryID = country[0].countryID;
                    countrieslist.push({ CountryID: country[0].countryID, CountryName: value.Country, Flag: "True" });
                }

                state = _.where($scope.State, { stateName: value.State });
                if (state.length == 0) {
                    $scope.StoreModel.StateID = lastStateID + 1;
                    lastStateID = lastStateID + 1;
                    stateslist.push({ StateID: lastStateID, StateName: value.State, CountryID: $scope.StoreModel.CountryID, Flag: "True" });
                }
                else {
                    $scope.StoreModel.StateID = state[0].stateID;
                    stateslist.push({ StateID: state[0].stateID, StateName: value.State, CountryID: $scope.StoreModel.CountryID, Flag: "True" });
                }

                district = _.where($scope.District, { districtName: value.District });

                if (district.length==0) {
                    $scope.StoreModel.DistrictID = lastDistrictID + 1;       
                    lastDistrictID = lastDistrictID + 1;
                    districtslist.push({ DistrictID: lastCountryID, DistrictName: value.District, RegionID: $scope.StoreModel.RegionID, StateID: $scope.StoreModel.StateID, Flag: "True" });
                }
                else
                {
                    $scope.StoreModel.DistrictID = district[0].districtID;
                    districtslist.push({ DistrictID: district[0].districtID, DistrictName: value.District, RegionID: $scope.StoreModel.RegionID, StateID: $scope.StoreModel.StateID, Flag: "True" });
                }
                city = _.where($scope.City, { cityName: value.City });

                if (city.length == 0) {
                    $scope.StoreModel.CityID = lastCityID + 1;
                    lastCityID = lastCityID + 1;
                    citieslist.push({ CityID: lastCityID, CityName: value.City, DistrictID: $scope.StoreModel.DistrictID, Flag:"True" })

                }
                else {
                    $scope.StoreModel.CityID = city[0].cityID;
                    citieslist.push({ CityID: city[0].cityID, CityName: value.City, DistrictID: $scope.StoreModel.DistrictID, Flag: "True" })
                }

                storetier = _.where($scope.StoreTier, { tier: value.Tier });

                if (storetier.length == 0) {
                    $scope.StoreModel.Tier = lastStoreTierID + 1;
                    lastStoreTierID = lastStoreTierID + 1;
                    storetierlist.push({ ID: lastStoreTierID, Tier: value.Tier, Flag: "True" })
                }
                else {
                    $scope.StoreModel.Tier = storetier[0].id;
                    storetierlist.push({ ID: storetier[0].id, Tier: value.Tier, Flag: "True" })
                }

                language = _.where($scope.Languages, { languageDescription: value.Language });

                if (language.length == 0) {
                    $scope.StoreModel.LanguageID = lastLanguageID  + 1;
                    lastLanguageID = lastLanguageID + 1;
                    languageslist.push({ ID: lastLanguageID, LanguageDescription: value.Language, Flag: "True" })
                }
                else {
                    $scope.StoreModel.LanguageID = language[0].id;
                    languageslist.push({ ID: language[0].id, LanguageDescription: value.Language, Flag: "True" })
                }
                storeformat = _.where($scope.StoreFormat, { Format: value.StoreFormat });

                if (storeformat.length == 0) {
                    $scope.StoreModel.StoreFormatID = lastStoreFormatID + 1;
                    lastStoreFormatID = lastStoreFormatID + 1;
                    storeFormatslist.push({ StoreFormatID: lastStoreFormatID, Format: value.StoreFormat, Flag: "True" })
                }
                else {
                    $scope.StoreModel.StoreFormatID = storeformat[0].storeFormatID;
                    storeFormatslist.push({ StoreFormatID: storeformat[0].storeFormatID, Format: value.StoreFormat, Flag: "True" })
                }

                $scope.StoreModel.ZipCode = value.ZipCode;

                $scope.storelist.push($scope.StoreModel); 


            });           

            var ExportModel = { StoreList: $scope.storelist, RegionList: regionlist, CountriesList: countrieslist, StatesList: stateslist, DistrictsList: districtslist, CitiesList: citieslist, StoreTiersList: storetierlist, LanguagesList: languageslist, StoreFormatList: storeFormatslist };

            $http({

                method: "POST",
                url: "/BoseCommon/AddStoreExportUtility",
                dataType: 'json',
                data:ExportModel,
                headers: { "Content-Type": "application/json" }
            }).then(function (msg) {
                alert("Store added successfully");
                window.location = "/api/store";
            }, function (error) {
                $scope.msg = "Error : Something Wrong";
            });
           
        }
        else {
            $scope.venuelist = [];
            angular.forEach(data, function (value, key) {
                $scope.VenueModel = {};
               // $scope.VenueModel.ID = 1;
                store = _.where($scope.Stores, { storeName: value.StoreName });
             
                $scope.VenueModel.VenueName = value.VenueName;
                $scope.VenueModel.StoreID = store[0].storeId;
                $scope.VenueModel.ContactName = value.ContactName;
                $scope.VenueModel.ContactEmail = value.ContactEmail;
                $scope.VenueModel.ContactPhone = value.ContactPhone;
                $scope.VenueModel.MobilePhone = value.MobilePhone;
                $scope.VenueModel.SecurityPhone = value.SecurityPhone;
                $scope.VenueModel.StreetAddress = value.StreetAddress;              
                $scope.venuelist.push($scope.VenueModel);
            });  
            $http({

                method: "POST",
                url: "/BoseCommon/AddVenueExportUtility",
                dataType: 'json',
                data: $scope.venuelist,
                headers: { "Content-Type": "application/json" }
            }).then(function (msg) {
                alert("Venue added successfully");
                window.location = "/api/venue";
            }, function (error) {
                $scope.msg = "Error : Something Wrong";
            });
        }      
    }   
    
    function GetRegionsList() {
        ExportUtilityService.getAllRegions().success(function (region) {
            $scope.Region = region;
            $scope.maxRegionID = Math.max.apply(Math, $scope.Region.map(function (item) { return item.regionID; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    function GetDistrictsList() {
        ExportUtilityService.getAllDistricts().success(function (district) {
            $scope.District = district;
            $scope.maxDistrictID = Math.max.apply(Math, $scope.District.map(function (item) { return item.districtID; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Countries List
    function GetCountriesList() {
        ExportUtilityService.getAllCountries().success(function (country) {
            $scope.Country = country;
            $scope.maxCountryID = Math.max.apply(Math, $scope.Country.map(function (item) { return item.countryID; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get States List
    function GetStatesList() {
        ExportUtilityService.getAllStates().success(function (state) {
            $scope.State = state;
            $scope.maxStateID = Math.max.apply(Math, $scope.State.map(function (item) { return item.stateID; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }

    //Get Cities List
    function GetCitiesList() {
        ExportUtilityService.getAllCities().success(function (city) {
            $scope.City = city;
            $scope.maxCityID = Math.max.apply(Math, $scope.City.map(function (item) { return item.cityID; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Store Tier
    function GetStoreTier() {
        ExportUtilityService.getAllStoreTiers().success(function (storetier) {
            $scope.StoreTier = storetier;
            $scope.maxStoreTierID = Math.max.apply(Math, $scope.StoreTier.map(function (item) { return item.id; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Languages List
    function GetLanguages() {
        ExportUtilityService.getAllLanguages().success(function (language) {
            $scope.Languages = language;
            $scope.maxLanguageID = Math.max.apply(Math, $scope.Languages.map(function (item) { return item.id; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    //Get Store Format
    function GetStoreFormat() {
        ExportUtilityService.getAllStoreFormats().success(function (storeformat) {
            $scope.StoreFormat = storeformat;
            $scope.maxStoreFormatID = Math.max.apply(Math, $scope.StoreFormat.map(function (item) { return item.storeFormatID; }));
        }).error(function () {
            alert('Error in getting records');
        });
    }
    function GetStoresList() {
        ExportUtilityService.getAllStores().success(function (store) {
            $scope.Stores = store;
        }).error(function () {
            alert('Error in getting records');
        });
    }
});