﻿var venuecontroller = app.controller('venueController', function ($scope, VenueService, $http, $timeout, $q, $log) {
    //displaying storelist div
    $scope.divVenueList = true;   
    
    //Binding the storelist
    GetVenuesList();
   GetStoresList();
    $scope.Venues = [];
    $scope.Stores = []; 
 
    //// Binding auto complte code for store search
    ////Begin 
    var self = this;
    self.simulateQuery = true;
    self.venues = loadAllVenues($http);
    self.querySearch = querySearch;
    self.selectedItemChange = selectedItemChange;
    self.searchTextChange = searchTextChange;
    function querySearch(query) {
        var results = query ? self.venues.filter(createFilterFor(query)) : self.venues, deferred;
        if (self.simulateQuery) {
            deferred = $q.defer();
            $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
            return deferred.promise;
        } else {
            return results;
        }
    }
    function selectedItemChange(item) {
        $scope.search = undefined;
        if (item.value != "") {
            $scope.search = item.value;
        }

        $log.info('Item changed to ' + JSON.stringify(item));
    }
    function searchTextChange(text) {
        $log.info('Text changed to ' + text);
    }
    function loadAllVenues($http) {
        var allVenues = [];
        var url = '';
        var result = [];
        VenueService.getAllVenues().then(function successCallback(response) {
            allVenues = response.data;
            angular.forEach(allVenues, function (venue, key) {
                result.push(
                    {
                        value: venue.venueName.toLowerCase(),
                        display: venue.venueName

                    });                
            });
        }, function errorCallback(response) {
            console.log('Oops! Something went wrong while fetching the data. Status Code: ' + response.status + ' Status statusText: ' + response.statusText);
        });
        return result;
    }
    function createFilterFor(query) {
        var lowercaseQuery = angular.lowercase(query);
        return function filterFn(venue) {
            return (venue.value.indexOf(lowercaseQuery) === 0);
        };
    }
    //End
    //Get Store list
    function GetStoresList() {
        VenueService.getAllStores().success(function (store) {
            $scope.Stores = store;
        }).error(function () {
            alert('Error in getting records');
        });
    }  
        
    function GetVenuesList() {
        VenueService.getAllVenues().success(function (venue) {
            $scope.Venues = venue;
        }).error(function () {
            alert('Error in getting records');
        });
    }
    $scope.AddNewVenue = function () {
        $scope.Action = "Add";
        $scope.divVenueList = false;
        $scope.divVenue = true;
        $scope.disableEditButton = { 'visibility': 'hidden' };
    }
    //Adding the store
    $scope.AddVenue = function (store) {
        $scope.venueModel = {};
        $scope.venueModel.StoreID = $scope.storeID;
        $scope.venueModel.VenueName = $scope.venueName;
        $scope.venueModel.StreetAddress = $scope.streetAddress;
        $scope.venueModel.ContactName = $scope.contactName;
        $scope.venueModel.ContactNumber = $scope.contactNumber;
        $scope.venueModel.ContactEmail = $scope.contactEmail;
        $scope.venueModel.MobilePhone = $scope.mobilePhone;
        $scope.venueModel.SecurityPhone = $scope.securityPhone;
        $scope.venueModel.ContactPhone = $scope.contactPhone;

        VenueService.AddNewVenue($scope.venueModel).success(function (msg) {
            alert(msg);
            window.location = "/api/venue";
        }, function () {
            alert('error in adding record');
        });
    }; 

    //Editiing the store
    $scope.editVenue = function (venue) {

        var getVenueData = VenueService.getVenue(venue.id);
        getVenueData.then(function (_venue) {
            $scope.id = venue.id;
            $scope.storeID = venue.storeID;
            $scope.venueName = venue.venueName;
            $scope.streetAddress = venue.streetAddress;
            $scope.contactName = venue.contactName;           
            $scope.contactEmail = venue.contactEmail;
            $scope.mobilePhone = venue.mobilePhone;
            $scope.securityPhone = venue.securityPhone;
            $scope.contactPhone = venue.contactPhone;           
            DisableEditVenue();
            $scope.Action = "Edit";
            $scope.divVenueList = false;
            $scope.divVenue = true;
            $scope.disableSubmitButton = { 'visibility': 'hidden' };
            $scope.disablePreviewButton = { 'visibility': 'hidden' };

        }, function () {
            alert('Error in getting book records');
        });
    };
    //Updating the store
    $scope.updateVenue = function () {        
        var getStoreAction = $scope.Action;
        if (getStoreAction == "Edit") {
            $scope.Action = "Update";
            EnableEditStore();
            $("#btnEdit").html('Update');
        }
        else {
            $scope.venueModel = {};
            $scope.venueModel.ID = $scope.id;
            $scope.venueModel.StoreID = $scope.storeID;
            $scope.venueModel.VenueName = $scope.venueName;
            $scope.venueModel.StreetAddress = $scope.streetAddress;
            $scope.venueModel.ContactName = $scope.contactName;
            $scope.venueModel.ContactPhone = $scope.contactPhone;
            $scope.venueModel.ContactEmail = $scope.contactEmail;
            $scope.venueModel.MobilePhone = $scope.mobilePhone;
            $scope.venueModel.SecurityPhone = $scope.securityPhone;           
            
            VenueService.updateVenue($scope.venueModel).success(function (msg) {
                alert(msg);
                window.location = "/api/venue"
            }, function () {
                alert('Error in updating book record');
            });

        }
    };

    //Deleting the store
    $scope.DeleteVenue = function ($scope) {

        $scope.id = $scope.id;
        $scope.storeID = $scope.storeID;
        $scope.venueName = $scope.venueName;
        $scope.streetAddress = $scope.streetAddress;
        $scope.contactName = $scope.contactName;
        $scope.contactEmail = $scope.contactEmail;
        $scope.mobilePhone = $scope.mobilePhone;
        $scope.securityPhone = $scope.securityPhone;
        $scope.contactPhone = $scope.contactPhone;    
        var getVenueData = VenueService.deleteVenue($scope.id);
        getVenueData.then(function (msg) {
            alert(msg.data);
            window.location = "/api/venue";
        }, function () {
            alert('Error in deleting book record');
        });
    };
    //Disabling the store fields
    function DisableEditVenue() {
        $(".editStoreID").attr("disabled", "disabled");
        $(".editVenueName").attr("disabled", "disabled");
        $(".editStreetAddress").attr("disabled", "disabled");
        $(".editContactName").attr("disabled", "disabled");
        $(".editContactPhone").attr("disabled", "disabled");
        $(".editContactEmail").attr("disabled", "disabled");
        $(".editMobilePhone").attr("disabled", "disabled");
        $(".editSecurityPhone").attr("disabled", "disabled");       
    }
    //Enabling the store fields
    function EnableEditStore() {
        $(".editStoreID").attr("disabled", false);
        $(".editVenueName").attr("disabled", false);
        $(".editStreetAddress").attr("disabled", false);
        $(".editContactName").attr("disabled", false);
        $(".editContactPhone").attr("disabled", false);
        $(".editContactEmail").attr("disabled", false);
        $(".editMobilePhone").attr("disabled", false);
        $(".editSecurityPhone").attr("disabled", false);       
    }
    

});

