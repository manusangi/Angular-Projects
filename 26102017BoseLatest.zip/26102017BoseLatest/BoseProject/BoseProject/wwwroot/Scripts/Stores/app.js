﻿$(function () {
    $("#date").datepicker({
        dateFormat: 'yy-mm-dd'
    });
});
(function () {
    'use strict';
    var app = angular
        .module('BoseApp', ['ngMaterial', 'ngMessages', 'material.svgAssetsCache']);

//  app.controller('CommonController', function ($scope, $http, $timeout, $q, $log) {
//        //$scope.divStoreList = true;
//        var self = this;
//        alert(this);
//        self.simulateQuery = true;
//        self.stores = loadAllStores($http);
//        self.querySearch = querySearch;
//        self.selectedItemChange = selectedItemChange;
//        self.searchTextChange = searchTextChange;
//        function querySearch(query) {
//            var results = query ? self.stores.filter(createFilterFor(query)) : self.stores, deferred;
//            if (self.simulateQuery) {
//                deferred = $q.defer();
//                $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
//                return deferred.promise;
//            } else {
//                return results;
//            }
//        }
//        function selectedItemChange(item) {
//            $scope.search = $scope.stores;
//            if (item.value != "") {
//                $scope.search = item.value;
//            }
//            $log.info('Item changed to ' + JSON.stringify(item));
//        }
//        function searchTextChange(text) {
//            $log.info('Text changed to ' + text);
//        }
//        function loadAllStores($http) {
//            var allStores = [];
//            var url = '';
//            var result = [];
//            url = 'api/products';
//            $http.get("/BoseCommon/StoreList/").then(function successCallback(response) {
//                allStores = response.data;
//                angular.forEach(allStores, function (store, key) {
//                    result.push(
//                        {
//                            value: store.storeName.toLowerCase(),
//                            display: store.storeName
//                        });
//                });
//            }, function errorCallback(response) {
//                console.log('Oops! Something went wrong while fetching the data. Status Code: ' + response.status + ' Status statusText: ' + response.statusText);
//            });
//            return result;
//        }
//        function createFilterFor(query) {
//            var lowercaseQuery = angular.lowercase(query);
//            return function filterFn(store) {
//                return (store.value.indexOf(lowercaseQuery) === 0);
//            };
//        };
//    //   app.controller('CommonController', AutoCompleteCtrl);
//    //function AutoCompleteCtrl($scope, $http, $timeout, $q, $log) {
//    //    //Autocomplete code begin 
//    //    //$scope.divStoreList = true;
//    //    var self = this;
//    //    alert(this);
//    //    self.simulateQuery = true;
//    //    self.stores = loadAllStores($http);        
//    //    self.querySearch = querySearch;
//    //    self.selectedItemChange = selectedItemChange;
//    //    self.searchTextChange = searchTextChange;
//    //    function querySearch(query) {
//    //        var results = query ? self.stores.filter(createFilterFor(query)) : self.stores, deferred;            
//    //        if (self.simulateQuery) {
//    //            deferred = $q.defer();
//    //            $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
//    //            return deferred.promise;
//    //        } else {
//    //            return results;
//    //        }
//    //    }
//    //    function selectedItemChange(item) {
//    //        $scope.search = $scope.stores;
//    //        if (item.value != "") {
//    //            $scope.search = item.value;
//    //        }           
//    //        $log.info('Item changed to ' + JSON.stringify(item));
//    //    }
//    //    function searchTextChange(text) {
//    //        $log.info('Text changed to ' + text);
//    //    }
//    //    function loadAllStores($http) {
//    //        var allStores = [];
//    //        var url = '';
//    //        var result = [];
//    //        url = 'api/products';
//    //        $http.get("/BoseCommon/StoreList/").then(function successCallback(response) {
//    //            allStores = response.data;
//    //            angular.forEach(allStores, function (store, key) {
//    //                result.push(
//    //                    {
//    //                        value: store.storeName.toLowerCase(),
//    //                        display: store.storeName
//    //                    });
//    //            });
//    //        }, function errorCallback(response) {
//    //            console.log('Oops! Something went wrong while fetching the data. Status Code: ' + response.status + ' Status statusText: ' + response.statusText);
//    //        });
//    //        return result;
//    //    }
//    //    function createFilterFor(query) {
//    //        var lowercaseQuery = angular.lowercase(query);
//    //        return function filterFn(store) {                
//    //            return (store.value.indexOf(lowercaseQuery) === 0);
//    //        };

//    //    }
//    ////    ///auto complete end
//    ////    //add store and storelist begin
//    ////    $http.get("/BoseCommon/StoreList/")
//    ////        .then(function (response) {
//    ////            $scope.Stores = response.data;
//    ////        })
//    ////    $scope.AddStoreDiv = function () {
//    ////        $scope.Action = "ADD";
//    ////        $scope.divStoreList = false;
//    ////        $scope.divStore = true;
//    ////    };
//    ////    app.filter('unique', function () {
//    ////        // we will return a function which will take in a collection
//    ////        // and a keyname
//    ////        return function (collection, keyname) {
//    ////            // we define our output and keys array;
//    ////            var output = [],
//    ////                keys = [];

//    ////            // we utilize angular's foreach function
//    ////            // this takes in our original collection and an iterator function
//    ////            angular.forEach(collection, function (item) {
//    ////                // we check to see whether our object exists
//    ////                var key = item[keyname];
//    ////                // if it's not already part of our keys array
//    ////                if (keys.indexOf(key) === -1) {
//    ////                    // add it to our keys array
//    ////                    keys.push(key);
//    ////                    // push this item to our final output array
//    ////                    output.push(item);
//    ////                }
//    ////            });
//    ////            // return our array which should be devoid of
//    ////            // any duplicates
//    ////            return output;
//    ////        };
//    ////    });
//    ////    $scope.AddUpdateStore = function () {
//    ////        $scope.storeModel = {};
//    ////        $scope.storeModel.StoreName = $scope.storeName;
//    ////        $scope.storeModel.StoreNumber = $scope.storeNumber;
//    ////        $scope.storeModel.StoreGeneralEmail = $scope.storeGeneralEmail;
//    ////        $scope.storeModel.PhoneNumber = $scope.phoneNumber;
//    ////        $scope.storeModel.StoreManager = $scope.storeManager;
//    ////        $scope.storeModel.StoreManagerEmail = $scope.storeManagerEmail;
//    ////        $scope.storeModel.StoreVisualLead = $scope.storeVisualLead;
//    ////        $scope.storeModel.StoreVisualLeadEmail = $scope.storeVisualLeadEmail;
//    ////        $scope.storeModel.StoreFormat = $scope.storeFormat;
//    ////        $scope.storeModel.Region = $scope.region;
//    ////        $scope.storeModel.District = $scope.district;
//    ////        $scope.storeModel.Tier = $scope.tier;
//    ////        $scope.storeModel.Language = $scope.language;
//    ////        $scope.storeModel.CostCenter = $scope.costCenter;
//    ////        $scope.storeModel.AddressLine1 = $scope.addressLine1;
//    ////        $scope.storeModel.City = $scope.city;
//    ////        $scope.storeModel.State_Province = $scope.state_Province;
//    ////        $scope.storeModel.ZipCode = $scope.zipCode;
//    ////        $scope.storeModel.Country = $scope.country;
//    ////        $scope.storeModel.Closed = $scope.closed;
//    ////        $scope.storeModel.ClosingDate = $scope.closingDate;
//    ////        $http({
//    ////            method: "post",
//    ////            url: "/BoseCommon/AddStore/",
//    ////            datatype: "json",
//    ////            data: JSON.stringify($scope.storeModel)
//    ////        }).then(function (response) {
//    ////            alert(response.data);
//    ////            window.location = "/api/Store"
//    ////        })

//    ////    };
//    //////add store End
//    //}
    
   

//})();




