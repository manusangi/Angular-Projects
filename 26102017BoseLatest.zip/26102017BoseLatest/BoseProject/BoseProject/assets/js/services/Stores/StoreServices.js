﻿app.service("StoreService", function ($http) {
    //get All Stores  
    this.getAllStores = function () {
        alert("dddd");
        return $http.get("/BoseCommon/StoreList/");
    }
   

});
