﻿app.controller('storeController', function ($scope, StoreService) {
    $scope.divStoreList = true;
    GetStoresList();
    $scope.stores = []; 
    //To Get All Records  
    function GetStoresList() {
        alert("dddd");
        StoreService.getAllStores().success(function (response) {           
            $scope.stores = response.data;
        }).error(function () {
            alert('Error in getting records');
        });
    }  
    //add store and storelist begin
    //get All Stores  

    $http.get("/BoseCommon/StoreList/")
        .then(function (response) {
            $scope.Stores = response.data;
        })
    $scope.AddStoreDiv = function () {
        $scope.Action = "ADD";
        $scope.divStoreList = false;
        $scope.divAddStore = true;
    };   
    $scope.AddUpdateStore = function () {
        $scope.storeModel = {};
        $scope.storeModel.StoreName = $scope.storeName;
        $scope.storeModel.StoreNumber = $scope.storeNumber;
        $scope.storeModel.StoreGeneralEmail = $scope.storeGeneralEmail;
        $scope.storeModel.PhoneNumber = $scope.phoneNumber;
        $scope.storeModel.StoreManager = $scope.storeManager;
        $scope.storeModel.StoreManagerEmail = $scope.storeManagerEmail;
        $scope.storeModel.StoreVisualLead = $scope.storeVisualLead;
        $scope.storeModel.StoreVisualLeadEmail = $scope.storeVisualLeadEmail;
        $scope.storeModel.StoreFormat = $scope.storeFormat;
        $scope.storeModel.Region = $scope.region;
        $scope.storeModel.District = $scope.district;
        $scope.storeModel.Tier = $scope.tier;
        $scope.storeModel.Language = $scope.language;
        $scope.storeModel.CostCenter = $scope.costCenter;
        $scope.storeModel.AddressLine1 = $scope.addressLine1;
        $scope.storeModel.City = $scope.city;
        $scope.storeModel.State_Province = $scope.state_Province;
        $scope.storeModel.ZipCode = $scope.zipCode;
        $scope.storeModel.Country = $scope.country;
        $scope.storeModel.Closed = $scope.closed;
        $scope.storeModel.ClosingDate = $scope.closingDate;
        $http({
            method: "post",
            url: "/BoseCommon/AddStore/",
            datatype: "json",
            data: JSON.stringify($scope.storeModel)
        }).then(function (response) {
            alert(response.data);
            window.location = "/api/Store"
        })

    };
    //add store End
});