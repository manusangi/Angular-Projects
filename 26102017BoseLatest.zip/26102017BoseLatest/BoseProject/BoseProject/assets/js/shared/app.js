﻿$(function () {
    $("#date").datepicker({
        dateFormat: 'yy-mm-dd'
    });
});
(function () {
    'use strict';
    var app = angular
        .module('BoseApp', ['ngMaterial', 'ngMessages', 'material.svgAssetsCache']);
       app.controller('storeController', storeCtrl);
       function storeCtrl($scope, $http, $timeout, $q, $log) {
        //Autocomplete code begin 
           $scope.divStoreList = true;
           GetStoreList();
        var self = this;
        self.simulateQuery = true;
        self.stores = loadAllStores($http);  
       
        self.querySearch = querySearch;
        self.selectedItemChange = selectedItemChange;
        self.searchTextChange = searchTextChange;
        function querySearch(query) {
            var results = query ? self.stores.filter(createFilterFor(query)) : self.stores, deferred;
            if (self.simulateQuery) {
                deferred = $q.defer();
                $timeout(function () { deferred.resolve(results); }, Math.random() * 1000, false);
                return deferred.promise;
            } else {
                return results;
            }
        }
        function selectedItemChange(item) {
            $scope.search = $scope.stores;
            if (item.value != "") {
                $scope.search = item.value;
            }           
            $log.info('Item changed to ' + JSON.stringify(item));
        }
        function searchTextChange(text) {
            $log.info('Text changed to ' + text);
        }
        function loadAllStores($http) {
            var allStores = [];
            var url = '';
            var result = [];
            url = 'api/products';
            $http.get("/BoseCommon/StoreList/").then(function successCallback(response) {
                allStores = response.data;
                angular.forEach(allStores, function (store, key) {
                    result.push(
                        {
                            value: store.storeName.toLowerCase(),
                            display: store.storeName
                        });
                });
            }, function errorCallback(response) {
                console.log('Oops! Something went wrong while fetching the data. Status Code: ' + response.status + ' Status statusText: ' + response.statusText);
            });
            return result;
        }
        function createFilterFor(query) {
            var lowercaseQuery = angular.lowercase(query);
            return function filterFn(store) {
                return (store.value.indexOf(lowercaseQuery) === 0);
            };

        }
        ///auto complete end
        
    }
    
   

})();




