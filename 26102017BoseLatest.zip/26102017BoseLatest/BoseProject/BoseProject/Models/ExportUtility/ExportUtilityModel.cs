﻿using BoseProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Models.ExportUtility
{
    public class ExportUtilityModel
    {
        public int ListID { get; set; }
        public string UploadFile { get; set; }

        public List<StoreModel> StoreList { get; set; }
        public List<Region> RegionList { get; set; }
        public List<Country> CountriesList { get; set; }
        public List<State> StatesList { get; set; }
        public List<District> DistrictsList { get; set; }
        public List<City> CitiesList { get; set; }
        public List<StoreTier> StoreTiersList { get; set; }
        public List<Languages> LanguagesList { get; set; }
        public List<StoreFormat> StoreFormatList { get; set; }
        
    }
}
