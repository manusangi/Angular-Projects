﻿using BoseProject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Web.Models.Venues;

namespace Web.Models
{
    public partial class Access_TestDBContext :DbContext
    {
        public static string ConnectionString { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(ConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<StoreModel>(entity =>
            {
                entity.Property(e => e.StoreNumber).HasColumnName("StoreNumber");

                entity.Property(e => e.StoreName).HasMaxLength(50);
            });
        }
        public virtual DbSet<StoreModel> StoreList { get; set; }
        public virtual DbSet<Region> Region { get; set; }
        public virtual DbSet<Country> Country { get; set; }
        public virtual DbSet<State> State { get; set; }
        public virtual DbSet<District> District { get; set; }
        public virtual DbSet<City> City { get; set; }
        public virtual DbSet<StoreTier> StoreTier { get; set; }
        public virtual DbSet<Languages> Languages { get; set; }
        public virtual DbSet<StoreFormat> StoreFormat { get; set; }
        public virtual DbSet<VenueModel> VenueName { get; set; }
    }
}
