﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.Models.Venues
{
    public partial class VenueModel
    {
        public int ID { get; set; }
        public string VenueName { get; set; }
        public int StoreID { get; set; }
        public string ContactName { get; set; }
        public string ContactEmail { get;set; }
        public string ContactPhone { get; set; }
        public string MobilePhone { get; set; }
        public string SecurityPhone { get; set; }
        public string StreetAddress { get; set; }

    }
}
