﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BoseProject.Models
{
    //StoreList table
    public partial class StoreModel
    {
        public int ID { get; set; }

        public string StoreNumber { get; set; }

        public string StoreManager { get; set; }

        public string StoreManagerEmail { get; set; }

        public string StoreGeneralEmail { get; set; }

        public string StoreVisualLead { get; set; }

        public string StoreVisualLeadEmail { get; set; }

        public string PhoneNumber { get; set; }

        public string StoreName { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public int CityID { get; set; }      

        public int StateID { get; set; }       

        public string ZipCode { get; set; }

        public int CountryID { get; set; }        

        public int StoreFormatID { get; set; }

        public int LanguageID { get; set; }

        public int DistrictID { get; set; }       

        public int Tier { get; set; }

        public string CostCenter { get; set; }

        public int RegionID { get; set; }        

        public string FixtureInstallationDescription { get; set; }

        public string InstallationCompany { get; set; }

        public string WindowSizes { get; set; }

        public DateTime? ClosingDate { get; set; }

        public bool? Closed { get; set; }

        public bool? SecurityRequired { get; set; }

        public string FirststWOWLocation { get; set; }

        public string FirststWOWPanelSize { get; set; }

        public string FirststWOWWallLength { get; set; }

        public string FirststWOWTVSize { get; set; }

        public string FeatureWallLocation { get; set; }
        public string GeneralDates { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public bool? Flag { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }


    }
    //Region table
    public partial class Region 
    {
        public int RegionID { get; set; }
        public string RegionCode { get; set; }
        public string RegionDescription { get; set; }
        public bool? Flag { get; set; }
    }
    //Country table
    public partial class Country
    {
        public int CountryID { get; set; }       
        public string CountryName { get; set; }
        public bool? Flag { get; set; }
    }

    //State table
    public partial class State
    {
        public int StateID { get; set; }
        public int CountryID { get; set; }      
        public string StateName { get; set; }
        public bool? Flag { get; set; }
    }
    //District Table
    public partial class District
    {
        public int DistrictID { get; set; }
        public string DistrictCode { get; set; }
        public string DistrictName { get; set; }
        public string MarketManager { get; set; }
        public string MarketManagerEmail { get; set; }
        public int RegionID { get; set; }
        public int StateID { get; set; }       
        public bool? Flag { get; set; }
    }
    //City table
    public partial class City
    {
        public int CityID { get; set; }
        public int DistrictID { get; set; }
        public string CityName { get; set; }
        public bool? Flag { get; set; }
    }

    //Store Tier table
    public partial class StoreTier
    {
        public int ID { get; set; }
        public string Tier { get; set; }
        public string Description { get; set; }
        public bool? Flag { get; set; }
    }
    //Languages Table
    public partial class Languages
    {
        public int ID { get; set; }
        public string LanguageDescription { get; set; }
        public string LanguageCode { get; set; }
        public bool? Flag { get; set; }
    }

    //Store Format Table
    public partial class StoreFormat
    {
        public int StoreFormatID { get; set; }
        public string Format { get; set; }
        public string Description { get; set; }
        public bool? Flag { get; set; }
    }  
}
