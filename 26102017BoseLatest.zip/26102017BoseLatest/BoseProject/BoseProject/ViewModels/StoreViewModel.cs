﻿using BoseProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Web.ViewModels
{
    public class StoreViewModel
    {
        public List<StoreModel> StoreList { get; set; }
        public List<Region> Region { get; set; }
        public List<Country> Country { get; set; }
        public List<State> State { get; set; }
        public List<District> District { get; set; }
        public List<City> City { get; set; }
        public List<StoreTier> StoreTier { get; set; }
        public List<Languages> Languages { get; set; }
        public List<StoreFormat> StoreFormat { get; set; }

    }
}
