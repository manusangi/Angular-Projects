﻿using BoseProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Web.Models.ExportUtility;
using Web.Models.Venues;

namespace Web.ViewModels
{
    public class ExportUtilityViewModel
    {
        public List<StoreModel> StoreList { get; set; }
        public List<Region> Region { get; set; }
        public List<Country> Country { get; set; }
        public List<State> State { get; set; }
        public List<District> District { get; set; }
        public List<City> City { get; set; }
        public List<StoreTier> StoreTier { get; set; }
        public List<Languages> Languages { get; set; }
        public List<StoreFormat> StoreFormat { get; set; }
        public List<VenueModel> VenueName { get; set; }


    }
}
