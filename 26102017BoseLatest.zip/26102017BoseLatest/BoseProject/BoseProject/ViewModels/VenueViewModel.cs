﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Web.Models.Venues;

namespace Web.ViewModels
{
    public class VenueViewModel
    {
        public List<VenueModel> VenueList { get; set; }
    }
}
