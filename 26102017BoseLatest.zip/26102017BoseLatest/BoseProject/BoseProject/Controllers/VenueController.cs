using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Models;
using Web.ViewModels;

namespace Web.Controllers
{
    [Produces("application/json")]
    [Route("api/Venue")]
    public class VenueController : Controller
    {
        Access_TestDBContext context = new Access_TestDBContext();
        public IActionResult VenueList()
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            ViewData["UserName"] = userName;
            VenueViewModel VVM = new VenueViewModel();
            return View(VVM);
        }
    }
}