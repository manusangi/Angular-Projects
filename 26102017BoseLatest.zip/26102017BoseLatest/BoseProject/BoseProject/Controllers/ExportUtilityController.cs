using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Web.Models;
using Web.ViewModels;
using Web.Models.ExportUtility;

namespace Web.Controllers
{
    [Produces("application/json")]   
    public class ExportUtilityController : Controller
    {
        Access_TestDBContext context = new Access_TestDBContext();
        [Route("api/ExportUtility")]
        [HttpGet]       
        public IActionResult ExportUtilityList(ExportUtilityModel exportUtilityModel)
        {
            int id = exportUtilityModel.ListID;
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            ViewData["UserName"] = userName;
            ExportUtilityViewModel EUVM = new ExportUtilityViewModel();
            return View(EUVM);
        }
       
    }
}