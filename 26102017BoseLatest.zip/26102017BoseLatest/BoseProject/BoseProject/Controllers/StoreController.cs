﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Web.Models;
using System.Linq;
using BoseProject.Models;
using System.Collections.Generic;
using Web.ViewModels;

namespace BoseProject.Controllers
{
    [Produces("application/json")]
    [Route("api/Store")]
    public class StoreController : Controller
    {
        Access_TestDBContext context = new Access_TestDBContext();
        [HttpGet]
        public IActionResult StoreList()
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            ViewData["UserName"] = userName;
            StoreViewModel SVM = new StoreViewModel();           
            return View(SVM);
        }  
    }
}
