using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Web.Models;
using BoseProject.Models;
using Web.Models.Venues;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using System.Text;
using OfficeOpenXml;
using System.Net;
using Web.ViewModels;
using Web.Models.ExportUtility;

namespace Web.Controllers
{
    public class BoseCommonController : Controller
    {
        Access_TestDBContext context = new Access_TestDBContext();
        public IActionResult Index()
        {
            return View();
        }
        private readonly IHostingEnvironment _hostingEnvironment;

        public BoseCommonController(IHostingEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpGet]
        public IActionResult StoreList()
        {
            var storeList = (from n in context.StoreList 
                             join r in context.Region on n.RegionID equals r.RegionID
                             join c in context.Country on n.CountryID equals c.CountryID
                             join s in context.State on n.StateID equals s.StateID
                             join d in context.District on n.DistrictID equals d.DistrictID
                             join cy in context.City on n.CityID equals cy.CityID
                             join t in context.StoreTier on n.Tier equals t.ID
                             join l in context.Languages on n.LanguageID equals l.ID
                             join f in context.StoreFormat on n.StoreFormatID equals f.StoreFormatID
                             select new
                             {
                                 storeId = n.ID,
                                 n.StoreNumber,
                                 n.StoreName,
                                 n.StoreManager,
                                 n.StoreManagerEmail,
                                 n.StoreGeneralEmail,

                                 n.PhoneNumber,
                                 n.StoreVisualLead,
                                 n.StoreVisualLeadEmail,
                                 r.RegionID,
                                 r.RegionDescription,

                                 c.CountryID,
                                 c.CountryName,
                                 s.StateID,
                                 s.StateName,
                                 d.DistrictID,

                                 d.DistrictName,
                                 cy.CityID,
                                 cy.CityName,
                                 tierID=t.ID,
                                 t.Tier,

                                 languageID=l.ID,
                                 l.LanguageDescription,
                                 n.ZipCode,
                                 n.CostCenter,
                                 n.AddressLine1,

                                 n.GeneralDates,
                                 n.Closed,                                
                                 n.SecurityRequired,
                                 n.ClosingDate,
                                 f.StoreFormatID
                             }).ToList();
            var response = storeList;
                return Json(response);
        }
       [HttpPost]
        public string AddStore([FromBody]StoreModel storeModel)
        {
            if(storeModel!=null)
            {
                storeModel.CreatedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                storeModel.CreatedDate = System.DateTime.Now;
                storeModel.Flag = true;
                context.StoreList.Add(storeModel);
               context.SaveChanges();
                return "Store added successfully";
            }
            else
            {
                return "Invalid Store record";
            }
        }

        public JsonResult GetCountry()
        {
            var CountryList = context.Country.ToList().Where(x=>x.Flag==true);
            return Json(CountryList);
        }
        [HttpPost]
        public JsonResult GetStates([FromBody]int CountryID)
        {
            var StateList = context.State.Where(x=>x.CountryID== CountryID & x.Flag==true).ToList();
            return Json(StateList);
        }
       
        public JsonResult GetStates()
        {
            var StatesList = context.State.ToList().Where(x => x.Flag == true);
            return Json(StatesList);
        }
        [HttpPost]
        public JsonResult GetDistricts([FromBody]int StateID)
        {
            var DistrictList = context.District.Where(x => x.StateID == StateID & x.Flag==true).ToList();
            return Json(DistrictList);
        }
        [HttpPost]
        public JsonResult GetCities([FromBody]int DistrictID)
        {
            var CityList = context.City.Where(x => x.DistrictID == DistrictID & x.Flag==true).ToList();
            return Json(CityList);
        }
        public JsonResult GetCities()
        {
            var CitiesList = context.City.ToList().Where(x => x.Flag == true);
            return Json(CitiesList);
        }
        public JsonResult GetRegion()
        {
            var RegionList = context.Region.ToList();
            return Json(RegionList);
        }
        public JsonResult GetDistricts()
        {
            var DistrictsList = context.District.ToList();
            return Json(DistrictsList);
        }
        public JsonResult GetLanguages()
        {
            var LanguagesList = context.Languages.ToList();
            return Json(LanguagesList);
        }
        public JsonResult GetStoreFormat()
        {
            var StoreFormatList = context.StoreFormat.ToList();
            return Json(StoreFormatList);
        }
        public JsonResult GetStoreTier()
        {
            var StoreTierList = context.StoreTier.ToList();
            return Json(StoreTierList);
        }
        //GET: Store by Id
        public JsonResult GetStoreById(string id)
        {           
                var storeId = Convert.ToInt32(id);
                var getStoreById = context.StoreList.Find(storeId);
                return Json(getStoreById);
            
        }
        // Update Store
        public string UpdateStore([FromBody]StoreModel storeModel)
        {
            if (storeModel != null)
            {               
                int storeId = Convert.ToInt32(storeModel.ID);
                StoreModel _store = context.StoreList.Where(b => b.ID == storeId).FirstOrDefault();
                _store.StoreName = storeModel.StoreName;
                _store.StoreNumber = storeModel.StoreNumber;
                _store.StoreGeneralEmail = storeModel.StoreGeneralEmail;
                _store.PhoneNumber = storeModel.PhoneNumber;
                _store.StoreManager = storeModel.StoreManager;
                _store.StoreManagerEmail = storeModel.StoreManagerEmail;
                _store.StoreVisualLead = storeModel.StoreVisualLead;
                _store.StoreVisualLeadEmail = storeModel.StoreVisualLeadEmail;
                _store.StoreFormatID = storeModel.StoreFormatID;
                _store.RegionID = storeModel.RegionID;
                _store.DistrictID = storeModel.DistrictID;
                _store.Tier = storeModel.Tier;
                _store.LanguageID = storeModel.LanguageID;
                _store.CostCenter = storeModel.CostCenter;
                _store.AddressLine1 = storeModel.AddressLine1;
                _store.CityID = storeModel.CityID;
                _store.StateID = storeModel.StateID;
                _store.ZipCode = storeModel.ZipCode;
                _store.CountryID = storeModel.CountryID;
                _store.Closed = storeModel.Closed;
                _store.ClosingDate = storeModel.ClosingDate;
                _store.GeneralDates = storeModel.GeneralDates;
                _store.SecurityRequired = storeModel.SecurityRequired;
                _store.ModifiedBy = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                _store.ModifiedDate = System.DateTime.Now;
                _store.Flag = true;
                 context.SaveChanges();
                 return "Store record updated successfully";
              
            }
            else
            {
                return "Invalid book record";
            }
        }
        // Delete store
        public string DeleteStore(string storeId)
        {

            if (!String.IsNullOrEmpty(storeId))
            {
                try
                {
                    int _storeId = Int32.Parse(storeId);                   
                    var _store = context.StoreList.Find(_storeId);
                    context.StoreList.Remove(_store);
                    context.SaveChanges();
                    return "Selected Store record deleted sucessfully";                   
                }
                catch (Exception)
                {
                    return "Store details not found";
                }
            }
            else
            {
                return "Invalid operation";
            }
        }
        [HttpGet]
        public IActionResult VenueList()
        {
            var venueList = (from n in context.VenueName join s in context.StoreList on n.StoreID equals s.ID select new { n.VenueName,n.ContactName,n.ContactPhone,n.ContactEmail,s.StoreName,n.MobilePhone,n.SecurityPhone,n.StreetAddress,n.ID,n.StoreID }).ToList();
            var response = venueList;
            return Json(response);
        }
        [HttpPost]
        public string AddVenue([FromBody]VenueModel venueModel)
        {
            if (venueModel != null)
            {
               context.VenueName.Add(venueModel);
               context.SaveChanges();
                return "Venue added successfully";
            }
            else
            {
                return "Invalid venue record";
            }
        }

        // Update venue
        public string UpdateVenue([FromBody]VenueModel venueModel)
        {
            if (venueModel != null)
            {
                int venueId = Convert.ToInt32(venueModel.ID);
                VenueModel _venue = context.VenueName.Where(b => b.ID == venueId).FirstOrDefault();
                _venue.VenueName = venueModel.VenueName;
                _venue.StoreID = venueModel.StoreID;
                _venue.StreetAddress = venueModel.StreetAddress;
                _venue.ContactName = venueModel.ContactName;
                _venue.ContactPhone = venueModel.ContactPhone;
                _venue.ContactEmail = venueModel.ContactEmail;
                _venue.MobilePhone = venueModel.MobilePhone;
                _venue.SecurityPhone = venueModel.SecurityPhone;
               
                context.SaveChanges();
                return "Venue record updated successfully";

            }
            else
            {
                return "Invalid book record";
            }
        }

        public JsonResult GetVenueById(string id)
        {
            var venueID = Convert.ToInt32(id);
            var getVenueById = context.VenueName.Find(venueID);
            return Json(getVenueById);

        }

        // Delete venue
        public string DeleteVenue(string venueId)
        {

            if (!String.IsNullOrEmpty(venueId))
            {
                try
                {
                    int _venueId = Int32.Parse(venueId);
                    var _venue = context.VenueName.Find(_venueId);
                    context.VenueName.Remove(_venue);
                    context.SaveChanges();
                    return "Selected venue record deleted sucessfully";
                }
                catch (Exception)
                {
                    return "Venue details not found";
                }
            }
            else
            {
                return "Invalid operation";
            }
        }

        [HttpGet]
        public IActionResult ExportUtilityList()
        {  
            return View();
        }
        [HttpPost]
        public string AddStoreExportUtility([FromBody] ExportUtilityModel Exportmodel)
        {
            if (Exportmodel != null)
            {
                foreach (var region in Exportmodel.RegionList)
                {
                    int regionsCount = context.Region.ToList().Where(x=>x.RegionID==region.RegionID).Count();
                    if (regionsCount == 0)
                    {
                        Region r = new Region();
                        r.RegionCode = r.RegionDescription = region.RegionDescription;
                        r.Flag = true;
                        context.Region.Add(r);
                    }                    
                }
                context.SaveChanges();
                foreach (var country in Exportmodel.CountriesList)
                {
                    int countriesCount = context.Country.ToList().Where(x => x.CountryID == country.CountryID).Count();
                    if (countriesCount == 0)
                    {
                        Country c = new Country();
                        c.CountryName = country.CountryName;
                        c.Flag = true;
                        context.Country.Add(c);
                    }
                }
                context.SaveChanges();
                foreach (var state in Exportmodel.StatesList)
                {
                    int statesCount = context.State.ToList().Where(x => x.StateID == state.StateID).Count();
                    if (statesCount == 0)
                    {
                        State s = new State();
                        s.StateName = state.StateName;
                        s.CountryID = state.CountryID;
                        s.Flag = true;
                        context.State.Add(s);
                    }
                }
                context.SaveChanges();
                foreach (var district in Exportmodel.DistrictsList)
                {
                    int districtsCount = context.District.ToList().Where(x => x.DistrictID == district.DistrictID).Count();
                    if (districtsCount == 0)
                    {
                        District d = new District();
                        d.DistrictName = district.DistrictName;
                        d.StateID = district.StateID;
                        d.RegionID = district.RegionID;
                        d.Flag = true;
                        context.District.Add(d);
                    }
                }
                context.SaveChanges();
                foreach (var city in Exportmodel.CitiesList)
                {
                    int citiesCount = context.City.ToList().Where(x => x.CityID == city.CityID).Count();
                    if (citiesCount == 0)
                    {
                        City cy = new City();
                        cy.CityName = city.CityName;
                        cy.DistrictID = city.DistrictID;
                        cy.Flag = true;
                        context.City.Add(cy);
                    }
                }
                context.SaveChanges();
                foreach (var tier in Exportmodel.StoreTiersList)
                {
                    int storeTiersCount = context.StoreTier.ToList().Where(x => x.ID == tier.ID).Count();
                    if (storeTiersCount == 0)
                    {
                        StoreTier st = new StoreTier();
                        st.Tier = tier.Tier;
                        st.Flag = true;
                        context.StoreTier.Add(st);
                    }
                }
                context.SaveChanges();
                foreach (var storeformat in Exportmodel.StoreFormatList)
                {
                    int storeFormatsCount = context.StoreFormat.ToList().Where(x => x.StoreFormatID == storeformat.StoreFormatID).Count();
                    if (storeFormatsCount == 0)
                    {
                        StoreFormat sf = new StoreFormat();
                        sf.Format =sf.Description= storeformat.Format;
                        sf.Flag = true;
                        context.StoreFormat.Add(sf);
                    }
                }
                context.SaveChanges();
                foreach (var language in Exportmodel.LanguagesList)
                {
                    int languagesCount = context.Languages.ToList().Where(x => x.ID == language.ID).Count();
                    if (languagesCount == 0)
                    {
                        Languages l = new Languages();
                        l.LanguageDescription = language.LanguageDescription;
                        l.Flag = true;
                        context.Languages.Add(l);
                    }
                }
                context.SaveChanges();
                foreach (var stores in Exportmodel.StoreList)
                {
                    StoreModel sm = new StoreModel();
                    sm.StoreName = stores.StoreName;
                    sm.StoreNumber = stores.StoreNumber;
                    sm.StoreManager = stores.StoreManager;
                    sm.StoreManagerEmail = stores.StoreManagerEmail;
                    sm.StoreVisualLead = stores.StoreVisualLead;
                    sm.StoreVisualLeadEmail = stores.StoreVisualLeadEmail;
                    sm.PhoneNumber = stores.PhoneNumber;
                    sm.AddressLine1 = stores.AddressLine1;
                    sm.RegionID = stores.RegionID;
                    sm.CountryID = stores.CountryID;
                    sm.StateID = stores.StateID;
                    sm.DistrictID = stores.DistrictID;
                    sm.CityID = stores.CityID;
                    sm.Tier = stores.Tier;
                    sm.StoreFormatID = stores.StoreFormatID;
                    sm.LanguageID = stores.LanguageID;
                    sm.ZipCode = stores.ZipCode;
                    context.StoreList.Add(sm);
                }
                context.SaveChanges();


                return "Store added successfully";
            }
            else
            {
                return "Invalid Store record";
            }

        }

        [HttpPost]
        public string AddVenueExportUtility([FromBody]List<VenueModel> VenueModel)
        {
            if (VenueModel != null)
            {
              
                foreach (var venue in VenueModel)
                {
                    VenueModel sm = new VenueModel();
                    sm.VenueName = venue.VenueName;
                    sm.StoreID = venue.StoreID;
                    sm.ContactName = venue.ContactName;
                    sm.ContactEmail = venue.ContactEmail;
                    sm.ContactPhone = venue.ContactPhone;
                    sm.MobilePhone = venue.MobilePhone;
                    sm.SecurityPhone = venue.SecurityPhone;
                    sm.StreetAddress = venue.StreetAddress;
                    context.VenueName.Add(sm);
                }
                context.SaveChanges();


                return "Venue added successfully";
            }
            else
            {
                return "Invalid Store record";
            }

        }
        [HttpPost]
        public string SaveRegion(string region)
        {
            region = region.Replace('"', ' ').Trim();
            int RegionID = 0;
            if (region != "")
            {
                int count = context.Region.Where(x => x.RegionDescription == region).Count();
                if (count == 0)
                {
                    Region r = new Region();
                    r.RegionCode = r.RegionDescription = region;
                    r.Flag = true;
                    context.Region.Add(r);
                    context.SaveChanges();
                }
                var regions= (from r1 in context.Region where r1.RegionDescription == region select r1.RegionID).ToList();
                RegionID = regions[0];
                return RegionID.ToString();
            }
            else
            {
                return null;
            }
        }

        

    }
}